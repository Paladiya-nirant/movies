const mongoose = require('mongoose');
const{arr} = require('../middleweres/uploads')

const sc = new mongoose.Schema({
    img : String,
    movie : String,
    language : Array,
    category : String,
    description : String

});

module.exports = mongoose.model('database', sc)