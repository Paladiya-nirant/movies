const m = require('../model/model');
const route = require('../routes/route');
const multer = require('../middleweres/uploads');
const fs = require('fs');
let data = []



const defaultpath = async(req, res) => {

    try{
        let d = await movie.find();
        console.log(movielist);
        res.render('index', {movie} );
    }
    catch(err){
        console.log(err);
    }

}

const addDoc = (req, res) => {

    const list = new film({
        name : req.body.name,
        author : req.body.author,
        rate : req.body.rate,
        discript : req.body.discript,
        languages : req.body.language,
        select : req.body.select,
        path : req.body.path
        
        
    })
        list.save();
        res.redirect('/');

}

module.exports = {defaultpath, addDoc}