const express = require('express');
const route = express();
const control = require('../controllers/controller');
const img = require('../middleweres/uploads')


route.get('/', control.defaultpath);

module.exports = route;