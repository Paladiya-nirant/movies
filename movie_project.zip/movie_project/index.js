const express = require('express');
const body_parser = require('body-parser');
let route = require('./routes/route');
const mongoose = require('./db/databaseform');
const control = require('./controllers/controller'); 
const multer = require('multer');
const path = require('path');

let app = express()



app.set('view engine', 'ejs');

app.use(body_parser.urlencoded({extended:true}));

app.use('/views/uploads', express.static('./views/uploads'));

app.use('/', route)

mongoose

app.listen(5001, () => {
    console.log('server running on 5001');
})
